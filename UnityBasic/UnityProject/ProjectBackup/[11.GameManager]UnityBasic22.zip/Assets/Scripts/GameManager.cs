﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameManager : MonoBehaviour
{
    public Responner responnerEangle;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if(responnerEangle.objPlayer)
        {
            Eagle eagle = responnerEangle.objPlayer.GetComponent<Eagle>();
            eagle.objResponPoint = responnerEangle.gameObject;
        }
    }
}
